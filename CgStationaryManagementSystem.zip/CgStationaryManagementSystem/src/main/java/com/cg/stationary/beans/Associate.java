package com.cg.stationary.beans;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Associate")
public class Associate {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	int associateId;
	String fullName;
	String emailId;
	String department;
	String designation;
	@OneToMany(mappedBy="associate",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@MapKey
	Map<Integer,Order> orders;
	/**
	 * 
	 */
	public Associate() {
		super();
	}
	/**
	 * @param associateId
	 * @param fullName
	 * @param emailId
	 * @param department
	 * @param designation
	 * @param orders
	 */
	public Associate(int associateId, String fullName, String emailId, String department, String designation,
			Map<Integer, Order> orders) {
		super();
		this.associateId = associateId;
		this.fullName = fullName;
		this.emailId = emailId;
		this.department = department;
		this.designation = designation;
		this.orders = orders;
	}
	/**
	 * @param fullName
	 * @param emailId
	 * @param department
	 * @param designation
	 */
	public Associate(String fullName, String emailId, String department, String designation) {
		super();
		this.fullName = fullName;
		this.emailId = emailId;
		this.department = department;
		this.designation = designation;
	}
	/**
	 * @param fullName
	 * @param emailId
	 * @param department
	 * @param designation
	 * @param orders
	 */
	public Associate(String fullName, String emailId, String department, String designation,
			Map<Integer, Order> orders) {
		super();
		this.fullName = fullName;
		this.emailId = emailId;
		this.department = department;
		this.designation = designation;
		this.orders = orders;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Map<Integer, Order> getorders() {
		return orders;
	}
	public void setorders(Map<Integer, Order> orders) {
		this.orders = orders;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + associateId;
		result = prime * result + ((department == null) ? 0 : department.hashCode());
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((fullName == null) ? 0 : fullName.hashCode());
		result = prime * result + ((orders == null) ? 0 : orders.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (associateId != other.associateId)
			return false;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (fullName == null) {
			if (other.fullName != null)
				return false;
		} else if (!fullName.equals(other.fullName))
			return false;
		if (orders == null) {
			if (other.orders != null)
				return false;
		} else if (!orders.equals(other.orders))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", fullName=" + fullName + ", emailId=" + emailId
				+ ", department=" + department + ", designation=" + designation + ", orders=" + orders + "]";
	}
}
