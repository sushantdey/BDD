package com.cg.stationary.services;

import java.util.List;

import com.cg.stationary.beans.Associate;
import com.cg.stationary.beans.Item;
import com.cg.stationary.beans.Order;
import com.cg.stationary.exceptions.AssociateNotFoundException;
import com.cg.stationary.exceptions.IncorrectItemNameException;
import com.cg.stationary.exceptions.InsufficientStockException;
import com.cg.stationary.exceptions.ItemAlreadyExistsException;
import com.cg.stationary.exceptions.ItemNotFoundException;
import com.cg.stationary.exceptions.ItemsNotFoundException;
import com.cg.stationary.exceptions.OrderNotFoundException;
import com.cg.stationary.exceptions.StationaryServicesDownException;

public interface StationaryServices {
	public int registerAssociate(Associate associate)throws StationaryServicesDownException;
	public List<Item> viewAllItems()throws StationaryServicesDownException, ItemsNotFoundException ;
	public int orderStationary(Order order)throws StationaryServicesDownException, AssociateNotFoundException, ItemNotFoundException, InsufficientStockException;
	public List<Order> viewAssociateAllOrders(int associateId)throws StationaryServicesDownException, AssociateNotFoundException, OrderNotFoundException;
	public int addItemToList(Item item)throws StationaryServicesDownException, ItemAlreadyExistsException;
	public void updateItemList(Item item)throws StationaryServicesDownException, ItemNotFoundException, IncorrectItemNameException;
	public void deleteItemFromList(Item item)throws StationaryServicesDownException, ItemNotFoundException;
	public List<Order> viewAllOrders()throws StationaryServicesDownException, OrderNotFoundException;
	public void cancelOrder(int associateId,int orderId)throws StationaryServicesDownException, AssociateNotFoundException, OrderNotFoundException;
}
