package com.cg.stationary.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.stationary.beans.Associate;
import com.cg.stationary.beans.Item;
import com.cg.stationary.beans.Order;

@Controller
public class URIController {
	Associate associate;
	Item item;
	Order order;
	@ModelAttribute
	public Associate getAssociate() {
		associate=new Associate();
		return associate;
	}
	@ModelAttribute
	public Item getItem() {
		item = new Item();
		return item;
	}
	@ModelAttribute
	public Order getOrder() {
		order = new Order();
		return order;
	}
	@RequestMapping(value= {"/","/home","/indexPage"})
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/associate")
	public String getAssociateIndexPage() {
		return "associateIndexPage";
	}
	@RequestMapping("/admin")
	public String getAdminIndexPage() {
		return "adminIndexPage";
	}
	@RequestMapping("/register")
	public String getRegisterPage() {
		return "registerPage";
	}
	@RequestMapping("/insertItemToList")
	public String getInsertItemToListPage() {
		return "insertItemToListPage";
	}
	@RequestMapping("/updateItemList")
	public String getUpdateItemListPage() {
		return "updateItemListPage";
	}
	@RequestMapping("/deleteItemFromList")
	public String getdeleteItemFromListPage() {
		return "deleteItemFromListPage";
	}
	@RequestMapping("/orderStationary")
	public String getOrderStationaryPage() {
		return "orderStationaryPage";
	}
	@RequestMapping("/viewAssociateOrders")
	public String getViewAssociateOrdersPage() {
		return "viewAssociateOrdersPage";
	}
	@RequestMapping("/cancelOrder")
	public String getCancelOrderPage() {
		return "cancelOrderPage";
	}
	
}
