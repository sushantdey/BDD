package com.cg.stationary.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.stationary.beans.Associate;
import com.cg.stationary.beans.Item;
import com.cg.stationary.beans.Order;
import com.cg.stationary.daoservices.AssociateDAO;
import com.cg.stationary.daoservices.ItemDAO;
import com.cg.stationary.daoservices.OrderDAO;
import com.cg.stationary.exceptions.AssociateNotFoundException;
import com.cg.stationary.exceptions.IncorrectItemNameException;
import com.cg.stationary.exceptions.InsufficientStockException;
import com.cg.stationary.exceptions.ItemAlreadyExistsException;
import com.cg.stationary.exceptions.ItemNotFoundException;
import com.cg.stationary.exceptions.ItemsNotFoundException;
import com.cg.stationary.exceptions.OrderNotFoundException;
import com.cg.stationary.exceptions.StationaryServicesDownException;
@Component("stationaryServices")
public class StationaryServicesImpl implements StationaryServices {
@Autowired
AssociateDAO associateDAO;
@Autowired
OrderDAO orderDAO;
@Autowired
ItemDAO itemDAO;
	@Override
	public int registerAssociate(Associate associate) throws StationaryServicesDownException{
		associate=associateDAO.save(associate);
		return associate.getAssociateId();
	}

	@Override
	public List<Item> viewAllItems() throws StationaryServicesDownException,ItemsNotFoundException{
		List<Item> items = itemDAO.findAll();
		if(items.isEmpty())
			throw new ItemsNotFoundException();
		return items;
	}

	@Override
	public int orderStationary(Order order)throws StationaryServicesDownException, AssociateNotFoundException, ItemNotFoundException, InsufficientStockException {
		associateDAO.findById(order.getAssociate().getAssociateId()).orElseThrow(()->new AssociateNotFoundException());
		Item item=itemDAO.findById(order.getItem().getItemId()).orElseThrow(()->new ItemNotFoundException());
		if(order.getCount()>item.getItemCount())
			throw new InsufficientStockException();
		itemDAO.updateItem(item.getItemId(), item.getItemCount()-order.getCount());
		order = orderDAO.save(order);
		return order.getOrderID();
	}

	@Override
	public List<Order> viewAssociateAllOrders(int associateId) throws StationaryServicesDownException, AssociateNotFoundException,OrderNotFoundException{
		Associate associate = associateDAO.findById(associateId).orElseThrow(()->new AssociateNotFoundException());
		Map<Integer, Order> ordersMap = associate.getorders();
		if(ordersMap.isEmpty())
			throw new OrderNotFoundException();
		List<Order> orders = new ArrayList<Order>(ordersMap.values());
		return orders;
	}

	@Override
	public int addItemToList(Item item) throws StationaryServicesDownException, ItemAlreadyExistsException {
		String itemName=item.getItemName();
		List<Item>items =itemDAO.findAll();
		for (Item item2 : items) {
			if(item2.getItemName().equals(itemName))
				throw new ItemAlreadyExistsException();
		}
		item = itemDAO.save(item);
		return item.getItemId();
	}

	@Override
	public void updateItemList(Item item) throws StationaryServicesDownException, ItemNotFoundException, IncorrectItemNameException{
		Item item1=itemDAO.findById(item.getItemId()).orElseThrow(()-> new ItemNotFoundException());
		item.setItemCount(item.getItemCount()+item1.getItemCount());
		if(item.getItemName().equals(item1.getItemName()))
			itemDAO.updateItem(item.getItemId(), item.getItemCount());
		else
			throw new IncorrectItemNameException();
	}
	
	@Override
	public void deleteItemFromList(Item item) throws StationaryServicesDownException,ItemNotFoundException {
		itemDAO.removeItem(item.getItemId());
	}

	@Override
	public List<Order> viewAllOrders()throws StationaryServicesDownException, OrderNotFoundException {
		List<Order> orders = orderDAO.findAll();
		if(orders.isEmpty())
			throw new OrderNotFoundException();
		return orders;
	}

	@Override
	public void cancelOrder(int associateId, int orderId)throws StationaryServicesDownException, AssociateNotFoundException, OrderNotFoundException {
		Associate associate = associateDAO.findById(associateId).orElseThrow(()->new AssociateNotFoundException());
		Map<Integer, Order> ordersMap = associate.getorders(); 
		Order order = ordersMap.get(orderId);
		if(order==null)
			throw new OrderNotFoundException();
		orderDAO.delete(order);
		Item item= itemDAO.findById(order.getItem().getItemId()).get();
		itemDAO.updateItem(order.getItem().getItemId(),item.getItemCount()+order.getCount());
	}

}
