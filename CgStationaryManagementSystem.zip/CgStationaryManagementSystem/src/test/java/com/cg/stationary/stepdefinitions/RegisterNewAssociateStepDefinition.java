package com.cg.stationary.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.stationary.pagebeans.RegisterPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterNewAssociateStepDefinition {
	WebDriver driver;
	RegisterPage registerPage;
	@Given("^Associate is on 'register page'$")
	public void associate_is_on_register_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("localhost:8084/register");
	    registerPage=PageFactory.initElements(driver, RegisterPage.class);
	}

	@When("^when associate enter valid credentials$")
	public void when_associate_enter_valid_credentials() throws Throwable {
		registerPage.setFullName("Sushant dey");
		registerPage.setDepartment("fresher");
		registerPage.setDesignation("senior analyst");
		registerPage.setEmailId("sushant@gmail.com");
		registerPage.clickSubmit();
	}

	@Then("^registration success page should appear$")
	public void registration_success_page_should_appear() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Success";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@When("^when associate enter invalid credentials$")
	public void when_associate_enter_invalid_credentials() throws Throwable {
		registerPage.setFullName("Sushant dey");
		registerPage.setDepartment("fresher");
		registerPage.setDesignation("senior analyst");
		registerPage.setEmailId("sushant");
		registerPage.clickSubmit();
	}

	@Then("^associate remains on the same page$")
	public void associate_remains_on_the_same_page() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Registration";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}
}
