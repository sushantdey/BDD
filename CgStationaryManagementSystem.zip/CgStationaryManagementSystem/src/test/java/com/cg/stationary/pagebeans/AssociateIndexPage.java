package com.cg.stationary.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AssociateIndexPage {
	@FindBy(how=How.NAME, name="register")
	private WebElement register;
	@FindBy(how=How.NAME, name="allItemDetails")
	private WebElement allItemDetails;
	@FindBy(how=How.NAME, name="orderStationary")
	private WebElement orderStationary;
	@FindBy(how=How.NAME, name="viewAssociateOrders")
	private WebElement viewAssociateOrders;
	@FindBy(how=How.NAME, name="cancelOrder")
	private WebElement cancelOrder;
	@FindBy(how=How.NAME, name="errorMessage")
	private WebElement errorMessage;
	@FindBy(how=How.NAME, name="success")
	private WebElement success;
	
	public AssociateIndexPage() {
		super();
	}
	public void clickRegister() {
		register.click();
	}
	public void clickAllItemDetails() {
		allItemDetails.click();
	}
	public void clickOrderStationary() {
		orderStationary.click();
	}
	public void clickViewAssociateOrders() {
		viewAssociateOrders.click();
	}
	public String getErrorMessage() {
		return errorMessage.getText();
	}
	public String getSuccess() {
		return success.getText();
	}
	public void clickCancelOrder() {
		cancelOrder.click();
	}
	
}
