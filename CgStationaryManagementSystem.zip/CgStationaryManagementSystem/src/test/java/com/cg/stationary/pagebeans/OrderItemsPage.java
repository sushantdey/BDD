package com.cg.stationary.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class OrderItemsPage {
	@FindBy(how=How.NAME, name="associate.associateId")
	private WebElement associateId;
	@FindBy(how=How.NAME, name="item.itemId")
	private WebElement itemId;
	@FindBy(how=How.NAME, name="count")
	private WebElement count;
	@FindBy(how=How.NAME, name="submit")
	private WebElement submit;
	public OrderItemsPage() {
		super();
	}
	public String getAssociateId() {
		return associateId.getAttribute("value");
	}
	public void setAssociateId(String associateId) {
		this.associateId.sendKeys(associateId);
	}
	public String getItemId() {
		return itemId.getAttribute("value");
	}
	public void setItemId(String itemId) {
		this.itemId.sendKeys(itemId);
	}
	public String getCount() {
		return count.getAttribute("value");
	}
	public void setCount(String count) {
		this.count.sendKeys(count);
	}
	public void clickSubmit() {
		submit.click();
	}
}
