package com.cg.stationary.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.stationary.pagebeans.AssociateIndexPage;
import com.cg.stationary.pagebeans.CancelOrderPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CancelOrderStepDefinition {
	WebDriver driver;
	CancelOrderPage cancelOrderPage;
	AssociateIndexPage associateIndexPage;
	@When("^Associate clicks 'cancel order' button$")
	public void associate_clicks_cancel_order_button() throws Throwable {
		associateIndexPage.clickCancelOrder();
	}

	@Then("^'cancel order' page should open$")
	public void cancel_order_page_should_open() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Orders";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@Given("^Associate is on 'cancel order' page$")
	public void associate_is_on_cancel_order_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("localhost:8084/cancelOrder");
		cancelOrderPage=PageFactory.initElements(driver, CancelOrderPage.class);
	}

	@When("^Associate enters valid order details$")
	public void associate_enters_valid_order_details() throws Throwable {
		cancelOrderPage.setAssociateId("1");
		cancelOrderPage.setOrderId("3");
		cancelOrderPage.clickSubmit();
	}

	@Then("^success cancel message should be displayed$")
	public void success_cancel_message_should_be_displayed() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Capgemini";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@When("^Associate enters invalid order details$")
	public void associate_enters_invalid_order_details() throws Throwable {
		cancelOrderPage.setAssociateId("9");
		cancelOrderPage.setOrderId("10");
		cancelOrderPage.clickSubmit();
	}

	@Then("^cancel order error message should be displayed$")
	public void cancel_order_error_message_should_be_displayed() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Orders";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}
}
