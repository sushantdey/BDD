package com.cg.stationary.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegisterPage {
	@FindBy(how=How.NAME, name="fullName")
	private WebElement fullName;
	@FindBy(how=How.NAME, name="department")
	private WebElement department;
	@FindBy(how=How.NAME, name="designation")
	private WebElement designation;
	@FindBy(how=How.NAME, name="emailId")
	private WebElement emailId;
	@FindBy(how=How.NAME, name="submit")
	private WebElement submit;

	public RegisterPage() {
		super();
	}
	public String getFullName() {
		return fullName.getAttribute("value");
	}
	public void setFullName(String fullName) {
		this.fullName.sendKeys(fullName);
	}
	public String getDepartment() {
		return department.getAttribute("value");
	}
	public void setDepartment(String department) {
		this.department.sendKeys(department);
	}
	public String getDesignation() {
		return designation.getAttribute("value");
	}
	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}
	public String getEmailId() {
		return emailId.getAttribute("value");
	}
	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}
	public void clickSubmit() {
		submit.click();
	}
}
