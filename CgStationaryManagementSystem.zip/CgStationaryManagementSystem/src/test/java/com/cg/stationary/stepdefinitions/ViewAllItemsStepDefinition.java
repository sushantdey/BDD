package com.cg.stationary.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.stationary.pagebeans.AssociateIndexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAllItemsStepDefinition {
	WebDriver driver;
	AssociateIndexPage associateIndexPage;
	@Given("^Associate is on 'associateIndexPage'$")
	public void associate_is_on_associateIndexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("localhost:8084/associate");
	    associateIndexPage=PageFactory.initElements(driver, AssociateIndexPage.class);
	}

	@When("^Associate clicks 'View All Items' button$")
	public void associate_clicks_View_All_Items_button() throws Throwable {
	    associateIndexPage.clickAllItemDetails();
	}

	@Then("^All items in stock should be displayed$")
	public void all_items_in_stock_should_be_displayed() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Success";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@Then("^No items found messsage should be displayed$")
	public void no_items_found_messsage_should_be_displayed() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Capgemini";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}
}
