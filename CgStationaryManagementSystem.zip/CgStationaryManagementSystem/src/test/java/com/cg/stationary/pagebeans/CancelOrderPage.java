package com.cg.stationary.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CancelOrderPage {
	@FindBy(how=How.NAME, name="associateId")
	private WebElement associateId;
	@FindBy(how=How.NAME, name="orderId")
	private WebElement orderId;
	@FindBy(how=How.NAME, name="submit")
	private WebElement submit;
	public CancelOrderPage() {
		super();
	}
	public String getAssociateId() {
		return associateId.getAttribute("value");
	}
	public void setAssociateId(String associateId) {
		this.associateId.sendKeys(associateId);
	}
	public String getOrderId() {
		return orderId.getAttribute("value");
	}
	public void setOrderId(String orderId) {
		this.orderId.sendKeys(orderId);
	}
	public void clickSubmit() {
		submit.click();
	}
}
