package com.cg.stationary.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.stationary.pagebeans.AssociateIndexPage;
import com.cg.stationary.pagebeans.OrderItemsPage;
import com.cg.stationary.pagebeans.ViewOrderPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewOrderStepDefinition {
	WebDriver driver;
	ViewOrderPage viewOrderPage;
	AssociateIndexPage associateIndexPage;
	@When("^Associate clicks 'View Order' button$")
	public void associate_clicks_View_Order_button() throws Throwable {
		associateIndexPage.clickViewAssociateOrders();
	}

	@Then("^'view order page' should appear$")
	public void view_order_page_should_appear() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Orders";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@Given("^Associate is on 'view order page'$")
	public void associate_is_on_view_order_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("localhost:8084/viewAssociateOrders");
		viewOrderPage=PageFactory.initElements(driver, ViewOrderPage.class);
	}

	@When("^Associate enters valid 'associateId'$")
	public void associate_enters_valid_associateId() throws Throwable {
	    viewOrderPage.setAssociateId("9");
	    viewOrderPage.clickSubmit();
	}

	@Then("^display order page should appear$")
	public void display_order_page_should_appear() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Associate Orders";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@When("^Associate enters invalid 'associateId'$")
	public void associate_enters_invalid_associateId() throws Throwable {
		viewOrderPage.setAssociateId("10");
	    viewOrderPage.clickSubmit();
	}

	@Then("^'error message' should appear$")
	public void error_message_should_appear() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Orders";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}
}
