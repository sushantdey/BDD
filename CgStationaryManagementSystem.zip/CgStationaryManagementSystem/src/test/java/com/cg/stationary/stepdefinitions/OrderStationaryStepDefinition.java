package com.cg.stationary.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.stationary.pagebeans.AssociateIndexPage;
import com.cg.stationary.pagebeans.OrderItemsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OrderStationaryStepDefinition {
	WebDriver driver;
	AssociateIndexPage associateIndexPage;
	OrderItemsPage orderItemsPage;

	@When("^Associate click 'Order Stationary' button$")
	public void associate_click_Order_Stationary_button() throws Throwable {
		associateIndexPage.clickOrderStationary();
	}

	@Then("^order stationary page should open$")
	public void order_stationary_page_should_open() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Insert items";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@Given("^Associate is on order stationary page$")
	public void associate_is_on_order_stationary_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("localhost:8084/orderStationary");
		orderItemsPage=PageFactory.initElements(driver, OrderItemsPage.class);
	}

	@When("^Associate enters valid details$")
	public void associate_enters_valid_details() throws Throwable {
		orderItemsPage.setAssociateId("9");
		orderItemsPage.setItemId("8");
		orderItemsPage.setCount("4");
	}

	@Then("^success message should be displayed$")
	public void success_message_should_be_displayed() throws Throwable {
		String actualSuccessMessage=associateIndexPage.getSuccess();
		String expectedSuccessMessage= "Order placed  successfully. Order Id is: 11";
		Assert.assertEquals(expectedSuccessMessage, actualSuccessMessage);
		driver.close();
	}

	@When("^Associate enters invalid details$")
	public void associate_enters_invalid_details() throws Throwable {
		orderItemsPage.setAssociateId("99");
		orderItemsPage.setItemId("8");
		orderItemsPage.setCount("4");
	}

	@Then("^error message should be displayed$")
	public void error_message_should_be_displayed() throws Throwable {
		String actualSuccessMessage=associateIndexPage.getSuccess();
		String expectedSuccessMessage= "Invalid Associate ID!!! Please Try Again.";
		Assert.assertEquals(expectedSuccessMessage, actualSuccessMessage);
		driver.close();
	}

}
