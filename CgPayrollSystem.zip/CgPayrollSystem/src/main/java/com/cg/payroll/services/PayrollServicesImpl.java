package com.cg.payroll.services;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.*;
@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private AssociateDAO associateDAO;
	@Override
	public Associate acceptAssociateDetails(Associate associate){
		associate=associateDAO.save(associate);
		return associate;
	}
	@Override
	public int calculateNetSalary(int associateId){
		Associate associate;
		associate=associateDAO.findById(associateId).get();
		associate.getSalary().setHra((30*associate.getSalary().getbasicSalary())/100);
		associate.getSalary().setCompanyPf(((125/10)*associate.getSalary().getbasicSalary())/100);
		associate.getSalary().setGratuity(((481/100)*associate.getSalary().getbasicSalary())/100);
		associate.getSalary().setEpf(((125/10)*associate.getSalary().getbasicSalary())/100);
		associate.getSalary().setConveyenceAllowance((5*associate.getSalary().getbasicSalary())/100);
		associate.getSalary().setOtherAllowance((20*associate.getSalary().getbasicSalary())/100);
		associate.getSalary().setPersonalAllowance((25*associate.getSalary().getbasicSalary())/100);
		associate.getSalary().setGrossSalary(associate.getSalary().getbasicSalary()+associate.getSalary().getHra()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance());
		int yearlySalary=(associate.getSalary().getGrossSalary()*12);
		if(yearlySalary<=250000){
			associate.getSalary().setMonthlyTax(0);
		}
		else if(yearlySalary>250000 && yearlySalary<=500000)
			associate.getSalary().setMonthlyTax((5*(yearlySalary-250000))/(100*12));
		else if(yearlySalary>500000 && yearlySalary<=1000000){
			int taxUpto5Lakh=12500;
			int taxUpto10Lakh=(20*(yearlySalary-500000))/100;
			associate.getSalary().setMonthlyTax((taxUpto5Lakh+taxUpto10Lakh)/12);
		}
		else if(yearlySalary>1000000){
			int taxUpto5Lakh=12500;
			int taxUpto10Lakh=100000;
			int taxAbove10Lakh=(30*(yearlySalary-1000000))/100;
			associate.getSalary().setMonthlyTax((taxUpto5Lakh+taxUpto10Lakh+taxAbove10Lakh)/12);
		}
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax());
		associateDAO.save(associate);
		return associate.getSalary().getNetSalary();

	}
	@Override
	public Associate getAssociateDetails(int associateId){
		Associate associate=associateDAO.findById(associateId).get();
		return associate;
	}
	@Override
	public ArrayList<Associate> getAllAsociateDetails(){
		return associateDAO.findAll();
	}
}