package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.IndexPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAssociateDetailsStepDefinition {
	WebDriver driver;
	IndexPage indexPage;
	@When("^Associate clicks on 'View Associate Details' button$")
	public void associate_clicks_on_View_Associate_Details_button() throws Throwable {
		indexPage.clickGetAssociateDetails();
	}

	@Then("^Associate is directed to 'viewAssociateDetailsPage'$")
	public void associate_is_directed_to_viewAssociateDetailsPage() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Associate Id";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@Given("^Associate is on 'viewAssociateDetailsPage'$")
	public void associate_is_on_viewAssociateDetailsPage() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Associate Id";
	    Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Then("^Associate is directed to 'displayAssociateDetailsPage'$")
	public void associate_is_directed_to_displayAssociateDetailsPage() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "associate Details";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}
}
