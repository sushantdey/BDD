package com.cg.payroll.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IndexPage {
	@FindBy(how=How.ID, id="register")
	private WebElement register;
	@FindBy(how=How.ID, id="calculateNetSalary")
	private WebElement calculateNetSalary;
	@FindBy(how=How.ID, id="getAssociateDetails")
	private WebElement getAssociateDetails;
	@FindBy(how=How.NAME, name="allAssociateDetails")
	private WebElement allAssociateDetails;
	public IndexPage() {
		super();
	}
	public void clickRegister() {
		register.click();
	}
	public void clickCalculateNetSalary() {
		calculateNetSalary.click();
	}
	public void clickGetAssociateDetails() {
		getAssociateDetails.click();
	}
	public void clickAllAssociateDetails() {
		allAssociateDetails.click();
	}
}
