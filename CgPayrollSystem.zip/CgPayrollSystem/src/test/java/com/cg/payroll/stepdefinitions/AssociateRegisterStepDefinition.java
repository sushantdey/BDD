package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.IndexPage;
import com.cg.payroll.pagebeans.RegisterPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AssociateRegisterStepDefinition {
	WebDriver driver;
	IndexPage indexPage;
	RegisterPage registerPage;
	@Given("^Associate is on the Capgemini Payroll System 'indexPage'$")
	public void associate_is_on_the_Capgemini_Payroll_System_indexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("localhost:8081");
	    indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^Associate clicks on 'Register' button$")
	public void associate_clicks_on_Register_button() throws Throwable {
		/*By submitField = By.name("register");
		WebElement submit = driver.findElement(submitField);
		submit.submit();*/
		indexPage.clickRegister();
	}

	@Then("^Associate is directed to 'registerPage'$")
	public void associate_is_directed_to_registerPage() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Registration";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@Given("^Associate is on 'registerPage'$")
	public void associate_is_on_registerPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("localhost:8081/register");
	    registerPage=PageFactory.initElements(driver, RegisterPage.class);
	}

	@When("^Associate enters valid Registration details$")
	public void associate_enters_valid_Registration_details() throws Throwable {
		/*By firstName = By.name("firstName");
		   WebElement fname = driver.findElement(firstName);
		   fname.sendKeys("Sushant");
		By lastName = By.name("lastName");
		   WebElement lName = driver.findElement(lastName);
		   lName.sendKeys("Dey");
		By department = By.name("department");
		   WebElement dept = driver.findElement(department);
		   dept.sendKeys("Fresher Pool");
		 By designation = By.name("designation");
		   WebElement design = driver.findElement(designation);
		   design.sendKeys("Senior Analyst");
		 By pancard = By.name("pancard");
		   WebElement pan = driver.findElement(pancard);
		   pan.sendKeys("");
		 By  emailId= By.name("emailId");
		   WebElement  emailID= driver.findElement(emailId);
		   emailID.sendKeys("sushant@gmail.com");
		 By  yearlyInvestmentUnder80c= By.name("yearlyInvestmentUnder80c");
		   WebElement yearlyInvestmentUnder80C = driver.findElement(yearlyInvestmentUnder80c);
		   yearlyInvestmentUnder80C.sendKeys("50000");
		 By  accountNumber= By.name("accountNumber");
		   WebElement  accountNo= driver.findElement(accountNumber);
		   accountNo.sendKeys("12345");
		 By  bankName= By.name("bankName");
		   WebElement  bName= driver.findElement(bankName);
		   bName.sendKeys("ICICI");
		 By  ifscCode= By.name("ifscCode");
		   WebElement  IFSCCode= driver.findElement(ifscCode);
		   IFSCCode.sendKeys("ICIC0000985");
		 By basicSalary = By.name("basicSalary");
		   WebElement  bSalary= driver.findElement(basicSalary);
		   bSalary.sendKeys("17300");
		By submitField = By.name("commit");
			WebElement submit = driver.findElement(submitField);
			submit.submit();*/
		registerPage.setFirstName("sushant");
		registerPage.setLastName("dey");
		registerPage.setDepartment("fresher");
		registerPage.setDesignation("senior analyst");
		registerPage.setPancard("ASFGJ2312N");
		registerPage.setEmailId("sushant@gmail.com");
		registerPage.setYearlyInvestmentUnder80c("50000");
		registerPage.setAccountNumber("12345");
		registerPage.setBankName("ICICI");
		registerPage.setIfscCode("ICIC0000985");
		registerPage.setBasicSalary("17300");
		registerPage.clickSubmit();
	}

	@Then("^Associate is directed to 'registrationSuccessPage'$")
	public void associate_is_directed_to_registrationSuccessPage() throws Throwable {
	    String actualTitle = driver.getTitle();
	    String expectedTitle = "Registration Success";
	    Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^Associate enters invalid Registration details$")
	public void associate_enters_invalid_Registration_details() throws Throwable {
		/*registerPage.setFirstName("sushant");
		registerPage.setLastName("dey");
		registerPage.setDepartment("fresher");
		registerPage.setDesignation("senior analyst");
		registerPage.setPancard("ASFGJ2312N");
		registerPage.setEmailId("sushant@gmail.com");
		registerPage.setYearlyInvestmentUnder80c("50000");
		registerPage.setAccountNumber("12345");
		registerPage.setBankName("ICICI");
		registerPage.setIfscCode("ICIC0000985");
		registerPage.setBasicSalary("17300");
		registerPage.clickSubmit();*/
	}

	@Then("^Display 'Registration Error message'$")
	public void display_Registration_Error_message() throws Throwable {
		/*String actualTitle = driver.getTitle();
	    String expectedTitle = "Registration";
	    Assert.assertEquals(expectedTitle, actualTitle);*/
		driver.close();
	}
}
