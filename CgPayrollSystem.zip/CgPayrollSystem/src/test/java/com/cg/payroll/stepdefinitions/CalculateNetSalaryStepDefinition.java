package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.CalculateNetSalaryPage;
import com.cg.payroll.pagebeans.IndexPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculateNetSalaryStepDefinition {
	WebDriver driver;
	IndexPage indexPage;
	CalculateNetSalaryPage calculateNetSalaryPage;
	@Given("^Associate is on the HomePage of 'Capgemini Payroll System'$")
	public void associate_is_on_the_HomePage_of_Capgemini_Payroll_System() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("localhost:8081");
	    indexPage=PageFactory.initElements(driver, IndexPage.class);
	}
	@When("^Associate clicks on 'Calculate Net Salary' button$")
	public void associate_clicks_on_Calculate_Net_Salary_button() throws Throwable {
	    indexPage.clickCalculateNetSalary();
	}
	@Then("^Associate is directed to 'calculateNetSalaryPage'$")
	public void associate_is_directed_to_calculateNetSalaryPage() throws Throwable {
		 	String actualTitle = driver.getTitle();
		    String expectedTitle = "Associate Id";
		    Assert.assertEquals(expectedTitle, actualTitle);
		    driver.close();
	}
	@Given("^Associate is on 'calculateNetSalaryPage'$")
	public void associate_is_on_calculateNetSalaryPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("localhost:8081/calculateNetSalary");
	    calculateNetSalaryPage=PageFactory.initElements(driver, CalculateNetSalaryPage.class);
	}
	@When("^Associate enters valid 'associateId'$")
	public void associate_enters_valid_associateId() throws Throwable {
			calculateNetSalaryPage.setAssociateId("1");
		   calculateNetSalaryPage.clickSubmit();
	}
	@Then("^Associate is directed to 'displayNetSalaryPage'$")
	public void associate_is_directed_to_displayNetSalaryPage() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Net Salary";
	    Assert.assertEquals(expectedTitle, actualTitle);
	}
	@When("^Associate enters invalid 'associateId'$")
	public void associate_enters_invalid_associateId() throws Throwable {
		By usernameField = By.name("associateId");
		   WebElement username = driver.findElement(usernameField);
		   username.sendKeys("0");
	}
	@Then("^Display 'Invalid associateId' Error message$")
	public void display_Invalid_associateId_Error_message() throws Throwable {
		driver.close();
	}
}
