package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.IndexPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAllAssociateDetailsStepDefinition {
	WebDriver driver;
	IndexPage indexPage;
	@Given("^Admin is on the HomePage of 'Capgemini Payroll System'$")
	public void admin_is_on_the_HomePage_of_Capgemini_Payroll_System() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("localhost:8081");
	    indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^Admin clicks on 'View All Associate Details' button$")
	public void admin_clicks_on_View_All_Associate_Details_button() throws Throwable {
	    indexPage.clickAllAssociateDetails();
	}

	@Then("^Admin is directed to 'viewAllAssociateDetailsPage'$")
	public void admin_is_directed_to_viewAllAssociateDetailsPage() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "All Associate Details";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}


}
